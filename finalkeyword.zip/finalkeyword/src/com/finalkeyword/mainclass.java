package com.finalkeyword;

public class mainclass extends A{
	
//	@Override
//		public void m1() {
//			System.out.println(" m1 overide method");
//		}
public static void main(String[] args) {
	A a = new A();
	//a.aid=22;
	a.m1();
	System.out.println(a.aid);
	
}
}
