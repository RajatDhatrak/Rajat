package com.finalkeyword;

public final class A {
	 final int aid=20;
	
	public final void m1() {
		System.out.println("m1  method of class a");
	}

}
