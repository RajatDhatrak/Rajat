package Validation;

import java.util.Scanner;
import java.util.regex.Pattern;



public class Validation {

	public static String validateAccountHolderName() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Name:");
		String name = sc.next();
		if (Pattern.matches("[a-zA-Z]+", name)) {
			// System.out.println("valid name");
			return name;
		} else {
			System.out.println("invalid input ");
			return validateAccountHolderName();
		}
	}

	public static String validatePanCardName() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your PanCardno:");
		String panno = sc.next();
		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}+", panno)) {
			// System.out.println("valid name");
			return panno;
		} else {
			System.out.println("invalid input ");
			return validatePanCardName();
		}
	}

	public static String validateAadharNo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Adhar no:");
		String Adharno = sc.next();
		if (Pattern.matches("[0-9]{12}+", Adharno)) {
			// System.out.println("valid name");
			return Adharno;
		} else {
			System.out.println("invalid input ");
			return validateAadharNo();
		}
	}

	public static String validateEmail() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Email id:");
		String Emailid = sc.next();
		if (Pattern.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$", Emailid)) {
			// System.out.println("valid name");
			return Emailid;
		} else {
			System.out.println("invalid input ");
			return validateEmail();
		}
	}
	
	public static long validateMobileno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your mobile no:");
		String mobileno = sc.next();
		long con = Long.valueOf(mobileno);	
		
				if (Pattern.matches("[0-9]{10}", mobileno)) {
			// System.out.println("valid name");
			return con;
		} else {
			System.out.println("invalid input ");
			return validateMobileno();
		}
	}

	
	
}
