package com.Exponent.bankapplication.controller;

import java.util.Scanner;

import com.Exponent.bankapplication.service.RBI;
import com.Exponent.bankapplication.serviceimp.SBI;

public class Admincontroller {
	
	public static int setPassword() {
		System.out.println("enter password");
		Scanner sc = new Scanner(System.in);
		int pass = sc.nextInt();
		int password = 1234;
		if(pass == password) {
			return pass;
		}
		else {
			System.out.println("Invalid Password");
			return setPassword();
		}
	}


	public static void main(String[] args) {
		setPassword();
		System.out.println("********************WELCOME TO SBI*******************");

		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		RBI rbi = new SBI();

		while (flag) {
			System.out.println("----------------------------------------------------");
			System.out.println("----------------------------------------------------");
			System.out.println("1: CREATE BANK ACCOUNT                              |");
			System.out.println("2: SHOW ACCOUNT DETAILS                             |");
			System.out.println("3: SHOW ACCOUNT BALANCE                             |");
			System.out.println("4: WITHDRAW MONEY                                   |");
			System.out.println("5: DEPOSIT MONEY                                    |");
			System.out.println("6: UPDATE ACCOUNT DETAILS                           |");
			System.out.println("7: DISPLAY SINGLE ACCOUNT                           |");
			System.out.println("8: EXIT                                             |"); 
			System.out.println("----------------------------------------------------");
			System.out.println("----------------------------------------------------");

			//System.out.println("Enter your choice between 1 to 8");

			int ch = getValidChoice() ;
			switch (ch) {
			case 1:
				rbi.createAccount();
				break;

			case 2:
				rbi.showAccountDetails();
				break;

			case 3:
				rbi.showAccountBalance();
				break;

			case 4:
				rbi.withdrawMoney();
				break;

			case 5:
				rbi.depositMoney();
				break;

			case 6:
				rbi.updateAccountDetails();
				break;

			case 7:
				rbi.displaysingleAccount();
				break;
			
			case 8:
				flag = false;
				break;

			default:
				System.out.println("enter invalid choice plz Enter correct Choice");
				break;

			}
		}
	}



public static int getValidChoice() {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your choice between 1 to 8:-");
	int ch ;
	try {
		ch = sc.nextInt();
		
	} catch (Exception e) {
		System.out.println("plz enter valid data");
		System.out.println(e);
		return getValidChoice();
	}
	
	return ch;
}


}




