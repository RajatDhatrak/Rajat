package com.Exponent.bankapplication.serviceimp;

import java.util.Iterator;
import java.util.Scanner;

import com.Exponent.bankapplication.model.Account;
import com.Exponent.bankapplication.service.RBI;

import Validation.Validation;

public class SBI implements RBI {
	Scanner sc = new Scanner(System.in);
	Account ac = new Account();
	Account a[] = new Account[5];

	@Override
	public void createAccount() {

		System.out.println("How many Accounts you want to add:-");
		int ch = getValidNo();

		for (int i = 0; i < ch; i++) {
			Account ac = new Account();

			System.out.println("Enter your account no:");
			int accNo = getValidNo();
			ac.setAccountNo(accNo);
			// System.out.println("Enter your name");
			ac.setAccountName(Validation.validateAccountHolderName());
			// System.out.println("Enter aadhar no:");
			ac.setAadharno(Validation.validateAadharNo());
			// System.out.println("Enter pancard no:");
			ac.setPancard(Validation.validatePanCardName());
			// System.out.println("Enter your mail ID");
			ac.setMail(Validation.validateEmail());
			// System.out.println("Enter your Contact no");
			ac.setContact(Validation.validateMobileno());
			System.out.println("Enter your Account opening balance:");
			ac.setAccountbalance(sc.nextDouble());
			System.out.println("account creation successs");

			a[i] = ac;
			System.out.println("Account added!!!");
		}
	}

	@Override
	public void showAccountDetails() {
		System.out.println("-----------show  all Account details----------");
		for (Account acn : a) {
			if (acn != null) {
				System.out.println(acn);
				}
			else {
				System.out.println("invalid Acc no");
			}
		}

	}

	@Override
	public void showAccountBalance() {
		//System.out.println("Enter your Account no");
		int accNo = sc.nextInt();
		boolean flag = false;
		for (Account acc : a) {

			if (acc != null && acc.getAccountNo() == accNo) {
				System.out.println("Current Account balance is:" + " " + acc.getAccountbalance());
				flag = true;
			}
		}
		if (!flag) {
			System.out.println("Account dosent Exist");
		}

	}

//		if (ac.getAccountNo() == accNo) {
//			System.out.println("Current Account balance is:" + " " + ac.getAccountbalance());
//		} else {
//			System.out.println("Account dosent Exist");
//		}
//
//	}

	@Override
	public void depositMoney() {
		System.out.println("Enter your Account no");
		int accNo = sc.nextInt();
		boolean flag = false;
		for (Account acc : a) {

			if (acc != null && acc.getAccountNo() == accNo) {
				System.out.println("plz enter DEPOSIT amount");
				int Damt = sc.nextInt();
				double updatedAccountbalance = acc.getAccountbalance() + Damt;
				ac.setAccountbalance(updatedAccountbalance);
				System.out.println("Current Account balance is:" + " " + updatedAccountbalance);

				flag = true;
			}
		}
		if (!flag) {
			System.out.println("Account dosent Exist");
		}

	}
		
	

	@Override
	public void withdrawMoney() {
		System.out.println("Enter your Account no");
		int accNo = sc.nextInt();
		boolean flag = false;
		for (Account acc : a) {

			if (acc != null && acc.getAccountNo() == accNo) {
				System.out.println("plz enter Withdraw amount");
				int Wamt = sc.nextInt();
				double updatedAccountbalance = acc.getAccountbalance() - Wamt;
				ac.setAccountbalance(updatedAccountbalance);
				System.out.println("Current Account balance is:" + " " + updatedAccountbalance);

				flag = true;
			}
		}
		if (!flag) {
			System.out.println("Account dosent Exist");
		}
	}
//		System.out.println("plz enter withdraw amount");
//		int Wamt = sc.nextInt();
//		double updatedAccountbalance = ac.getAccountbalance() - Wamt;
//		ac.setAccountbalance(updatedAccountbalance);

	
	@Override
	public void updateAccountDetails() {
		System.out.println("Enter your Account no");
		int accNo = sc.nextInt();
		boolean flag = true;
		for (Account acc : a) {
		if (acc != null && acc.getAccountNo() == accNo) {

			System.out.println("1.Enter new name");
			System.out.println("2.Enter new contact no");
			System.out.println("3.Enter new mail id");
			System.out.println("4.Exit");
			System.out.println("Enter your choice between 1 to 4");
			
			while (flag) {
				int update = sc.nextInt();
				switch (update) {
				case 1:

					System.out.println("Enter new Name:");
					for (Account acc1 : a) {
						if (acc1 != null ) {
					String newname = sc.next();
					acc1.setAccountName(newname);
						}}

					break;
				case 2:
					System.out.println("Enter new Mobile no:");
					for (Account acc1 : a) {
						if (acc1 != null ) {
					int newcontactno = sc.nextInt();
					acc1.setContact(newcontactno);
						}}
					break;

				case 3:
					System.out.println("Enter new Email id:");
					for (Account acc1 : a) {
						if (acc1 != null ) {
					String newmailid = sc.next();
					acc1.setMail(newmailid);
						}}

					break;
				case 4:
					flag = false;
					break;

				default:
					System.out.println("enter invalid choice plz Enter correct Choice");
					break;
					
					
				}
				
			}
			
			//flag = true;
			
		} 
		
		
	}
		if(!flag) {
			System.out.println("Account dosent Exist");
		}
	}

	@Override
	public void displaysingleAccount() {
		// TODO Auto-generated method stub
		System.out.println("Enter the Account no:-");
		long an = sc.nextLong();
		for (Account acn : a) {
			if (acn != null && acn.getAccountNo() == an) {
				System.out.println(acn);
			} else {
				System.out.println("invalid input");
			}

		}

	}
	public static int getValidNo() {
		Scanner sc = new Scanner(System.in);
	//	System.out.println("Enter your choice between 1 to 8:-");
		int ch ;
		try {
			ch = sc.nextInt();
			
		} catch (Exception e) {
			System.out.println("plz enter valid data");
			System.out.println(e);
			return getValidNo();
		}
		
		return ch;
	}

}
